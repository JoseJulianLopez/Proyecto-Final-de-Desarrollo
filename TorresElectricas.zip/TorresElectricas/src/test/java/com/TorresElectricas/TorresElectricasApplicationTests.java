package com.TorresElectricas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TorresElectricasApplicationTests {

	@Test
	void contextLoads() {
	}

}
