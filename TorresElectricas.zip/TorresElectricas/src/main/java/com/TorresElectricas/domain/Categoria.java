package com.TorresElectricas.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.List;
import lombok.Data;

@Data
@Entity
@Table(name = "torre")

public class Categoria implements Serializable { //serializacion porque se va almacenar ciertos datos en el disco

    private static final long serialVersionUID = 1L; //para poder hacer el ciclo de la sumatoria de la categoria.

    @Id //id categoria es la llave de la tabla categoria. 
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Los valores generados que estrategia usan, identico a la BD 
    @Column(name = "id_torre") //decir cual es el nombre en la base de datos. Se hace la asociación 
    private long idTorre;
    private String codigo;
    private String descripcion;
    private String RutaImagen;
    private boolean activo;
    private String ubicacion;
    private double altura;
    private String fecha_instalacion;
    private String estado;

//
//    @OneToMany
//    @JoinColumn (name = "id_torre")
//    List<Producto> productos;
    
    public Categoria() {
    }

    public Categoria(String descripcion, String rutaImagen, boolean activo) {
        this.descripcion = descripcion;
        this.RutaImagen = rutaImagen;
        this.activo = activo;
    }

}
