package com.TorresElectricas.dao;

import com.TorresElectricas.domain.Rol;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolDao extends JpaRepository<Rol, Long> {

}
